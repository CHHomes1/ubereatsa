import client from '@sanity/client';
export default client({
    projectId: 'k4ves9h0',
    dataset: 'production',
})